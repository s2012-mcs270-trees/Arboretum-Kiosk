package edu.gac.arboretumweb.client;

public interface Page 
{
	/**
	 * This method is to be called by the PageController when a page is to be hidden, but 
	 * the data on the page should be maintained.
	 */
	public void close();
	
	/**
	 * This method is to be called by the PageController when a page that was hidden by close() is 
	 * to now be shown.  (Like pressing the BACK button on a page.)
	 */
	public void reload();	
}
