package edu.gac.arboretumweb.client;

import java.util.ArrayList;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.dom.client.Style.Position;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Image;

import edu.gac.arboretumweb.client.SearchParameter.SearchFor;
import edu.gac.arboretumweb.shared.domain.Tree;
import com.google.gwt.user.client.ui.Button;

public class TreePage implements EntryPoint, Page {
	//closeButton.addClickHandler(new ClickHandler() {
	//public void onClick(ClickEvent event) {
	// dialogBox.hide();
	// searchButton.setEnabled(true);
	// searchButton.setFocus(true);
	//}
	//});

	RootPanel rootPanel;
	Tree tree = new Tree();
	
	public void show(Tree tree1, final SearchParameter sp)
	{
		//public void showTreePage(Tree tree){
		// TODO Auto-generated method stub
		rootPanel = RootPanel.get();
		rootPanel.setSize("1600", "900");
		rootPanel.getElement().getStyle().setPosition(Position.RELATIVE);

		Label lblYourTree = new Label("Your Tree");
		rootPanel.add(lblYourTree, 550, 10);

		String zoom = "17";
		Float treeLatitude = (float) Double.valueOf(tree.getLatitude()).doubleValue();
		Float treeLongitude = (float) Double.valueOf(tree.getLongitude()).doubleValue();
		Float ArbLat = (float) 44.319897;
		Float ArbLong = (float) -93.975149;
		Float centerLatitude = (float) 44.323303;//44.320855;
		Float centerLongitude = (float) -93.973274; //-93.976064;
		String mapType = "hybrid";
		//Google maps refuses to center on anything other than the arboretum center. not sure why. even when hardcoding other centers in... puzzling.
		if (treeLatitude > 44.32252 || treeLongitude > -93.974755){
			zoom = "16";
			centerLatitude = (float) 44.323303;
			centerLongitude = (float) -93.973274;
			mapType = "road";
		}
		//Float centerLatitude = (float) (44.319897 +((treeLatitude - ArbLat)/2.0));
		//Float centerLongitude = (float) (-93.975149 + ((treeLongitude - ArbLong)/2.0));
		System.out.println("centerLatitude: " + centerLatitude);
		System.out.println("centerLongitude: " + centerLongitude);
		System.out.println("treeLatitude: " + treeLatitude);
		System.out.println("treeLongitude: "+ treeLongitude);
		System.out.println("Arb Lat: "+ ArbLat);
		System.out.println("Arb Long: " + ArbLong); 
		String url = new String("http://maps.googleapis.com/maps/api/staticmap?center=44.319897,%-93.975149&zoom=" + zoom + "&size=512x512&maptype=" + mapType + "&markers=color:blue%7Clabel:S%7C44.319897, -93.975149&markers=color:green%7Clabel:G%7C" + tree.getLatitude() + "," + tree.getLongitude() + "&sensor=false");
		Image image = new Image((String) url);
		rootPanel.add(image, 10, 34);
		image.setSize("479px", "409px");

		Label lblCommonName = new Label("Common Name");
		rootPanel.add(lblCommonName, 531, 34);
		lblCommonName.setSize("92px", "18px");
		Label lblTreecommonname = new Label(tree.getCommonName());
		rootPanel.add(lblTreecommonname, 531, 58);
		Label lblScientificName = new Label("Scientific Name");
		rootPanel.add(lblScientificName, 531, 131);
		Label lblTreescientificname = new Label(tree.getScientificName());
		rootPanel.add(lblTreescientificname, 531, 155);
		Label lblYearPlanted = new Label("Year Planted");
		rootPanel.add(lblYearPlanted, 531, 219);
		Label lblTreeyearplanted = new Label(tree.getYearPlanted());
		rootPanel.add(lblTreeyearplanted, 531, 243);
		Label lblYearDonated = new Label("Year Donated");
		rootPanel.add(lblYearDonated, 531, 301);
		Label lblTreeyeardonated = new Label(tree.getYearDonated());
		rootPanel.add(lblTreeyeardonated, 531, 325);
		Label lblDonatedFor = new Label("Donated For");
		rootPanel.add(lblDonatedFor, 531, 380);
		Label lblTreedonatedfor = new Label(tree.getDonatedFor());
		rootPanel.add(lblTreedonatedfor, 531, 404);
		Button btnHomePage = new Button("Home Page");
		rootPanel.add(btnHomePage, 879, 34);
		btnHomePage.setSize("115px", "55px");
		btnHomePage.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				rootPanel.clear();
				PageController.sharedPageController().showMainPage();
			}
		});

		Button btnBack = new Button("Back");
		rootPanel.add(btnBack, 879, 119);
		btnBack.setSize("112px", "55px");
		btnBack.addClickHandler(new ClickHandler() 
		{
			public void onClick(ClickEvent event) 
			{
				ArrayList<SearchFor> searchForParams = new ArrayList<SearchFor>();
				searchForParams.add(SearchFor.trees);
				rootPanel.clear();
				PageController.sharedPageController().showSearchResultsPage(sp);
			}
		});
	}

	@Override
	public void onModuleLoad() 
	{
		ArrayList<SearchFor> searchForParams = new ArrayList<SearchFor>();
		searchForParams.add(SearchFor.trees);
		//show(tree, );
	}


	@Override
	public void close() 
	{
		rootPanel.clear();
	}


	@Override
	public void reload() 
	{
		
	}
}